# Grinch YouTuber Blocks — Fabric / Minecraft Java 1.21.11

This project uses the **seven images you uploaded** as textures for seven separate cube blocks. Textures are resized to 64×64 pixels and applied to all six sides of each block.

Block IDs:
- `grinchyoutuberblocks:creator_1`
- `grinchyoutuberblocks:grinch`
- `grinchyoutuberblocks:creator_2`
- `grinchyoutuberblocks:creator_3`
- `grinchyoutuberblocks:creator_4`
- `grinchyoutuberblocks:creator_5`
- `grinchyoutuberblocks:creator_6`

## Get the JAR using the included GitHub Actions workflow

This environment has Java 21 but no Gradle installation and no internet access to download Gradle/Minecraft dependencies, so I cannot compile and verify the JAR directly here. The included workflow can build it on GitHub's runner.

1. Create a new repository on GitHub.
2. Upload the contents of this ZIP (the files inside, not the ZIP itself) to the repository.
3. Open the repository's **Actions** tab and enable workflows if prompted.
4. Run **Build Grinch YouTuber Blocks** using **Run workflow**, or make a commit to `main`.
5. Open the completed workflow run. In **Artifacts**, download `Grinch-YouTuber-Blocks-JAR.zip`. Inside is the `.jar` file.

## Install
- For single-player: place the `.jar` in `.minecraft/mods`.
- For Aternos multiplayer: install the same mod on the Fabric server and on each player's client. Use the matching Minecraft 1.21.11 Fabric installation.

## Give yourself the blocks
```
/give @s grinchyoutuberblocks:creator_1
/give @s grinchyoutuberblocks:grinch
/give @s grinchyoutuberblocks:creator_2
/give @s grinchyoutuberblocks:creator_3
/give @s grinchyoutuberblocks:creator_4
/give @s grinchyoutuberblocks:creator_5
/give @s grinchyoutuberblocks:creator_6
```

The workflow and dependency versions are based on the Fabric 1.21.11 toolchain. The JAR still needs a successful workflow run before it can be considered built/tested.

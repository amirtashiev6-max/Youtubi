package com.grinch.youtuberblocks;

import net.fabricmc.api.ModInitializer;
import net.minecraft.block.AbstractBlock;
import net.minecraft.block.Block;
import net.minecraft.block.Blocks;
import net.minecraft.item.BlockItem;
import net.minecraft.item.Item;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.util.Identifier;

public class GrinchYouTuberBlocks implements ModInitializer {
    public static final String MOD_ID = "grinchyoutuberblocks";

    public static final Block CREATOR_1 = register("creator_1", Blocks.RED_CONCRETE);
    public static final Block GRINCH = register("grinch", Blocks.LIME_CONCRETE);
    public static final Block CREATOR_2 = register("creator_2", Blocks.BLUE_CONCRETE);
    public static final Block CREATOR_3 = register("creator_3", Blocks.PURPLE_CONCRETE);
    public static final Block CREATOR_4 = register("creator_4", Blocks.ORANGE_CONCRETE);
    public static final Block CREATOR_5 = register("creator_5", Blocks.BROWN_CONCRETE);
    public static final Block CREATOR_6 = register("creator_6", Blocks.CYAN_CONCRETE);

    private static Block register(String path, Block template) {
        Block block = new Block(AbstractBlock.Settings.copy(template));
        Identifier id = Identifier.of(MOD_ID, path);
        Registry.register(Registries.BLOCK, id, block);
        Registry.register(Registries.ITEM, id, new BlockItem(block, new Item.Settings()));
        return block;
    }

    @Override
    public void onInitialize() {
    }
}
